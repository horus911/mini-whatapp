// 🔧 Remplace par ta propre configuration Firebase :
const firebaseConfig = {
  apiKey: "TA_CLE_API",
  authDomain: "TON_PROJET.firebaseapp.com",
  databaseURL: "https://TON_PROJET.firebaseio.com",
  projectId: "TON_PROJET",
  storageBucket: "TON_PROJET.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

let currentUser = null;

function login() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider)
    .then((result) => {
      currentUser = result.user;
      document.getElementById("user-info").innerHTML =
        "Connecté : <strong>" + currentUser.displayName + "</strong>";
      listenForMessages();
    })
    .catch((error) => console.error("Erreur de connexion :", error));
}

function sendMessage() {
  const msg = document.getElementById("message").value;
  if (!msg || !currentUser) return;
  db.ref("messages").push({
    name: currentUser.displayName,
    text: msg,
    time: Date.now()
  });
  document.getElementById("message").value = "";
}

function listenForMessages() {
  const chat = document.getElementById("chat");
  db.ref("messages").on("child_added", (snapshot) => {
    const data = snapshot.val();
    const msgEl = document.createElement("div");
    msgEl.textContent = data.name + " : " + data.text;
    chat.appendChild(msgEl);
    chat.scrollTop = chat.scrollHeight;
  });
}